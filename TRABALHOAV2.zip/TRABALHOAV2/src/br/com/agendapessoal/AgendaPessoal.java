
package br.com.agendapessoal;

import br.com.agendapessoal.dao.ContatoDAO;
import br.com.agendapessoal.dao.Database;
import br.com.agendapessoal.dao.EmailDAO;
import br.com.agendapessoal.dao.LogradouroDAO;
import br.com.agendapessoal.dao.TelefoneDAO;
import br.com.agendapessoal.model.Email;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


 
public class AgendaPessoal {

    public static void main(String[] args) {

        criarTabelas();
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Digite seu Nome:");
//        System.out.println("Digite seu Sobrenome:");
//        System.out.println("Digite seu Apelido:");
//        System.out.println("Informe seu Sexo:");
//        System.out.println("Digite sua Data de Nascimento:");
//        System.out.println("Digite seu E-mail:");
//        System.out.println("Digite seu Numero de telefone:");
//        System.out.println("Infome seu endereço:");
        exibirMenu();

    }

    private static void exibirMenu() {
        Scanner sc = new Scanner(System.in);
        int op;
        do {
            clearConsole();
            try {
                System.out.println("+++  Agenda de Contatos  +++");
                System.out.println("Digite: ");
                System.out.println("   1 - Cadastrar");
                System.out.println("   2 - Alterar");
                System.out.println("   3 - Consultar");
                System.out.println("   4 - Excluir");
                System.out.println("   0 - Sair");
                System.out.print("Sua opcao: ");
                op = sc.nextInt();
            } catch (Exception exp) {
                op = 0;
            }
        } while (op != 0);
    }

    private static void clearConsole() {
        try {
            String os = System.getProperty("os.name");
            Runtime.getRuntime().exec(os.contains("Windows") ? "cls" : "clear");
        } catch (final Exception e) {
        }
    }

    private static void criarTabelas() {
        Connection conn;
        try {
            conn = new Database().getConexao();
            PreparedStatement ps = conn.prepareStatement(new ContatoDAO().createTable);
            ps = conn.prepareStatement(new EmailDAO().createTable);
            ps = conn.prepareStatement(new LogradouroDAO().createTable);
            ps = conn.prepareStatement(new TelefoneDAO().createTable);
            ps.execute();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            Logger.getLogger(AgendaPessoal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
