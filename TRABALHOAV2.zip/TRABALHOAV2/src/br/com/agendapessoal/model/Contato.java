/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.model;

import br.com.agendapessoal.dao.EmailDAO;
import br.com.agendapessoal.dao.LogradouroDAO;
import br.com.agendapessoal.dao.TelefoneDAO;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Cria do em 04/12/2017
 *
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */
public class Contato implements Comparable<Contato> {

    private Integer id;
    private String nome;
    private String sobrenome;
    private String apelido;
    private String sexo;
    private Date dataNascimento;

    private List<Logradouro> enderecos;
    private List<Telefone> telefones;
    private List<Email> emails;

    @Override
    public String toString() {
        return "Contato{" + "id=" + id + ", nome=" + nome + ", sobrenome=" + sobrenome + ", apelido=" + apelido + ", sexo=" + sexo + ", dataNascimento=" + dataNascimento + '}';
    }

    @Override
    public int compareTo(Contato o) {
        return this.getNome().compareTo(o.getNome());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public List<Logradouro> getEnderecos() {
        try {
            return new LogradouroDAO().todosContato(this.id);
        } catch (Exception ex) {
            Logger.getLogger(Contato.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public List<Telefone> getTelefones() {
        try {
            return new TelefoneDAO().todosContato(this.id);
        } catch (Exception ex) {
            Logger.getLogger(Contato.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public List<Email> getEmails() {
        try {
            return new EmailDAO().todosContato(this.id);
        } catch (Exception ex) {
            Logger.getLogger(Contato.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

}
