/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.model;

/**
 * 
 * Cria do em 04/12/2017
 * 
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */

public class Email {
    private int id;
    private int idContato;
    private String descricao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdContato() {
        return idContato;
    }

    public void setIdContato(int idContato) {
        this.idContato = idContato;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }    
    
    @Override
    public String toString() {
        return "Email{" + "id=" + id + ", idContato=" + idContato + ", descricao=" + descricao + '}';
    }
    
}
