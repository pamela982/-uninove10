/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.dao;

import java.util.List;

/**
 *
 * Cria do em 04/12/2017
 *
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */
public class TelefoneDAO implements DAO{

    @Override
    public void atualizar(Object object) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(Object object) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object procurarId(Integer id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void salvar(Object object) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List todos() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List todosContato(Integer id) throws Exception {
        return null;
    }
    
}
