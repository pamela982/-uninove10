/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.dao;

import java.util.List;

/**
 *
 * Cria do em 04/12/2017
 *
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */
public interface DAO {

    void atualizar(Object object) throws Exception;
    void excluir(Object object) throws Exception;
    Object procurarId(Integer id) throws Exception;
    void salvar(Object object) throws Exception;
    List todos() throws Exception;
    
}
