/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.dao;

import br.com.agendapessoal.model.Logradouro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * Cria do em 04/12/2017
 *
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */
public class LogradouroDAO implements DAO{
    private final String tabela = "logradouro";
    private final String colIdContato = "IdContato";
    private final String colId = "Id";
    private final String colBairro = "Bairro";
    private final String colCidade = "Cidade";
    private final String colUf = "Uf";
    private final String colNumero = "Numero";
    private final String colComplemento = "Complemento";
		  
    

    public final String createTable = "CREATE TABLE IF NOT EXISTS " + tabela + "("
            + colId + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + colIdContato + " INTEGER NOT NULL, "
			+ colBairro + " VARCHAR(15) NOT , "
			+ colComplemento + " VARCHAR(25) NOT ,  "
			+ colCidade + " VARCHAR(15) NOT , "
            + colUf + " VARCHAR(3) NOT , "
			+ colNumero + " INTEGER(5) NOT , "
		    + ");";

    @Override
     public void atualizar(Object object) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Logradouro logradouro = (Logradouro) object;
        if (logradouro == null) {
            throw new Exception("o valor passado nao pode ser nulo");
        }
        try {
            String sql = "UPDATE " + tabela + " SET "
                    + colIdContato + "=?, "
                    + colBairro + "=? "
                    + colCidade + "=? "
                    + colComplemento + "=? "
                    + colUf + "=? "
                    + colNumero + "=? "
                    + "WHERE " + colId + "=?;";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, logradouro.getIdContato());
            ps.setString(2, logradouro.getBairro());
             ps.setString(3,logradouro.getCidade());
             ps.setString(4, logradouro.getComplemento());
             ps.setString(5, logradouro.getUf());
             ps.setInt(6, logradouro.getNumero());
             ps.setInt(7, logradouro.getId());
            ps.execute();
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
     public void excluir(Object object) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Logradouro logradouro = (Logradouro) object;
        if (logradouro == null) {
            throw new Exception("o valor passado nao pode ser nulo");
        }
        try {
            String sql = "DELETE FORM " + tabela + " WHERE " + colId + " = ?;";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, logradouro.getId());
            ps.execute();
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public Logradouro procurarId(Integer id) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Logradouro logradouro= null;
        try {
            String sql = "SELECT * FROM " + tabela + " WHERE " + colId + " = " + id + ";";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.first()) {
                logradouro = new Logradouro();
                logradouro.setId(rs.getInt(colId));
                logradouro.setIdContato(rs.getInt(colIdContato));
                logradouro.setBairro(rs.getString(colBairro));
                logradouro.setComplemento(rs.getString(colComplemento));
                logradouro.setCidade(rs.getString(colCidade));
                logradouro.setUf(rs.getString(colUf));
		logradouro.setNumero(rs.getInt(colNumero));
            }
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return logradouro;
    }

    @Override
     public void salvar(Object object) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Logradouro logradouro  = (Logradouro) object;
        if (logradouro == null) {
            throw new Exception("o valor passado nao pode ser nulo");
        }
        try {
            String sql = "INSERT INTO " + tabela + "("
                    + colIdContato + ','
                    + colBairro + ','
                    + colCidade + ','
                    + colComplemento + ','
		    + colNumero + ','
                    + colUf
                    + ") values(?,?,?,?,?,?);";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, logradouro.getIdContato());
            ps.setString(2, logradouro.getBairro());
            ps.setString(3, logradouro.getCidade());
            ps.setString(4, logradouro.getComplemento());
	    ps.setString(5, logradouro.getUf());
	    ps.setInt(6, logradouro.getNumero());
			
           
            ps.execute();
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public List<Logradouro> todos() throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        List<Logradouro> logradouros = new ArrayList<>();
        try {
            String sql = "SELECT * FROM " + tabela + ";";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Logradouro logradouro = new Logradouro();
                logradouro.setId(rs.getInt(colId));
                logradouro.setIdContato(rs.getInt(colIdContato));
                logradouro.setBairro(rs.getString(colBairro));
                logradouro.setComplemento(rs.getString(colComplemento));
                logradouro.setCidade(rs.getString(colCidade));
                logradouro.setUf(rs.getString(colUf));
                logradouro.setNumero(rs.getInt(colNumero));
		logradouros.add(logradouro);
            }
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return logradouros;
    }
    
    public List todosContato(Integer id) throws Exception {
        return null;
    }
    
}
