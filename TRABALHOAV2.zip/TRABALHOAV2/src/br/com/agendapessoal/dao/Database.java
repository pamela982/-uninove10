/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * 
 * Cria do em 04/12/2017
 * 
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */
public class Database {    
    
    private final String driver = "com.mysql.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost:3306/";
    private final String usuario = "root";
    private final String senha = "";
    
    private final String nomeBanco = "agendapessoal" ;
    
    public Connection getConexao() throws Exception {
        Class.forName(driver);
            return DriverManager.getConnection(url+nomeBanco, usuario, senha);
    }   
}
