/*
 *
 * Este projeto foi desenvolvido com critério de avaliação para composição da AV2.
 * @disciplina de Programação Orientada a Objetos
 *
 * @professor Edson Melo de Souza 
 *
 */
package br.com.agendapessoal.dao;

import br.com.agendapessoal.model.Email;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * Cria do em 04/12/2017
 *
 * @autor Ivam Henrique Marques dos Santos RA 316107371
 * @autor Jonathas de Almeida Pinto RA 315101014
 * @autor Matheus dos Santos RA 917205296
 */
public class EmailDAO implements DAO {

    private final String tabela = "email";
    private final String colId = "id";
    private final String colIdContato = "IdContato";
    private final String colDescricao = "Descricacao";

    public final String createTable = "CREATE TABLE IF NOT EXISTS " + tabela + "("
            + colId + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + colIdContato + " INTEGER NOT NULL, "
            + colDescricao + " VARCHAR(50) NOT NULL, "
            + ");";

    @Override
    public void atualizar(Object object) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Email email = (Email) object;
        if (email == null) {
            throw new Exception("o valor passado nao pode ser nulo");
        }
        try {
            String sql = "UPDATE " + tabela + " SET "
                    + colIdContato + "=?, "
                    + colDescricao + "=? "
                    + "WHERE " + colId + "=?;";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, email.getIdContato());
            ps.setString(2, email.getDescricao());
            ps.setInt(6, email.getId());
            ps.execute();
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public void excluir(Object object) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Email email = (Email) object;
        if (email == null) {
            throw new Exception("o valor passado nao pode ser nulo");
        }
        try {
            String sql = "DELETE FORM " + tabela + " WHERE " + colId + " = ?;";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, email.getId());
            ps.execute();
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public Email procurarId(Integer id) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Email email = null;
        try {
            String sql = "SELECT * FROM " + tabela + " WHERE " + colId + " = " + id + ";";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.first()) {
                email = new Email();
                email.setId(rs.getInt(colId));
                email.setIdContato(rs.getInt(colIdContato));
                email.setDescricao(rs.getString(colDescricao));

            }
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return email;
    }

    @Override
    public void salvar(Object object) throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        Email email = (Email) object;
        if (email == null) {
            throw new Exception("o valor passado nao pode ser nulo");
        }
        try {
            String sql = "INSERT INTO " + tabela + "("
                    + colIdContato + ','
                    + colDescricao + ','
                    + ") values(?,?);";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, email.getIdContato());
            ps.setString(2, email.getDescricao());
            ps.execute();
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public List<Email> todos() throws Exception {
        PreparedStatement ps = null;
        Connection conn = null;
        List<Email> emails = new ArrayList<>();
        try {
            String sql = "SELECT * FROM " + tabela + ";";
            conn = new Database().getConexao();
            ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Email email = new Email();
                email.setId(rs.getInt(colId));
                email.setIdContato(rs.getInt(colIdContato));
                email.setDescricao(rs.getString(colDescricao));
                emails.add(email);
            }
        } catch (SQLException sqle) {
            throw new Exception("erro ao inserir dados" + sqle);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return emails;
    }

    public List todosContato(Integer id) throws Exception {
        return null;
    }

}
