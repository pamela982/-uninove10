/*
c. crie uma classe CamaroteInferior (que possui a localização do
ingresso e métodos para acessar e imprimir esta localização)
 */
package ingresso;

public class CamaroteInferior {
    
    
    
    
}
