/*
CamaroteSuperior que é mais cara (possui valor adicional).
Esta última possui um método para retornar o valor do ingresso.
Ambas as classes herdam a classe Vip
 */
package ingresso;

public class CamaroteSuperior extends Vip {

}
