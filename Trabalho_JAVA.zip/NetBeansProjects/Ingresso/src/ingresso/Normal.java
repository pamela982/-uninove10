package ingresso;

public class Normal extends Ingresso {

    private double ingressoNormal = 100;

    public double getIngressoNormal() {
        return ingressoNormal;
    }

}
