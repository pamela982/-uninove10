package ingresso;

public class Vip extends Ingresso {

    double valorVip = 150;
    private double valorAdicional;
    private double retornoValorVip;

    public double getRetornoValorVip() {

        this.retornoValorVip = valorVip + valorAdicional;
        return this.retornoValorVip;
    }

    public double getValorAdicional() {
        return valorAdicional;
    }

    public void setValorAdicional(double valorAdicional) {
        this.valorAdicional = valorAdicional;
    }

}
