package ingresso;

import java.util.Scanner;

public class Ingresso {

    private double imprimeValor;

    public static void main(String[] args) {

        int opcao;
        String entrada;

        System.out.println("Escolha a opção de ingresso pelo setor: ");
        System.out.println("1 - NORMAL ");
        System.out.println("2 - VIP ");
        System.out.println("3 - CAMAROTE INFERIOR");
        System.out.println("4 - CAMAROTE SUPERIOR");

        Scanner in = new Scanner(System.in);
        entrada = in.next();
        opcao = Integer.parseInt(entrada);

        switch (opcao) {

            case 1:
                Normal normal1 = new Normal();
                normal1.getIngressoNormal();
                System.out.println("O valor do ingresso NORMAL é de: " + normal1.getIngressoNormal());
                break;

            case 2:
                Vip vip1 = new Vip();
                vip1.setValorAdicional(100);
                System.out.println("o valor do ingresso VIP com o adicional é: " + vip1.getRetornoValorVip());
                break;

            case 3:

                System.out.println("Camarote Inferior");
                break;

            case 4:

                System.out.println("Camarote Superior");
                break;

            default:
                System.out.println("Opção de Ingresso Inválido");

        }

    }

}
