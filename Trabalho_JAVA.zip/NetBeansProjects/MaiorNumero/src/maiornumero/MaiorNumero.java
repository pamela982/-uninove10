package maiornumero;

import java.util.Scanner;

public class MaiorNumero {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int num1, num2, maior;

        String entrada;

        //Leitura do Primeiro Número
        System.out.println("Entre com o Primeiro Número:");
        entrada = in.next();
        num1 = Integer.parseInt(entrada);
        //Leitura do Segundo Número
        System.out.println("Entre com o Segundo Número:");
        entrada = in.next();
        num2 = Integer.parseInt(entrada);

        if (num1 > num2) {
            maior = num1;
        } else {
            maior = num2;
        }
        System.out.println("O Maior Número é:\n" + maior);

    }

}
